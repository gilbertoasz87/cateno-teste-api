package org.indices.rest.client;

import io.quarkus.test.junit.NativeImageTest;

@NativeImageTest
public class CountriesResourceIT extends CountriesResourceTest {

    // Run the same tests

}